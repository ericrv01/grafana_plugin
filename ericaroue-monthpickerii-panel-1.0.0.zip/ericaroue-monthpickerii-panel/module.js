define(["@grafana/data","react","@grafana/runtime","@grafana/ui","@emotion/css"],((e,t,n,r,a)=>(()=>{"use strict";var o={644:e=>{e.exports=a},305:t=>{t.exports=e},545:e=>{e.exports=n},388:e=>{e.exports=r},650:e=>{e.exports=t}},l={};function c(e){var t=l[e];if(void 0!==t)return t.exports;var n=l[e]={exports:{}};return o[e](n,n.exports,c),n.exports}c.n=e=>{var t=e&&e.__esModule?()=>e.default:()=>e;return c.d(t,{a:t}),t},c.d=(e,t)=>{for(var n in t)c.o(t,n)&&!c.o(e,n)&&Object.defineProperty(e,n,{enumerable:!0,get:t[n]})},c.o=(e,t)=>Object.prototype.hasOwnProperty.call(e,t),c.r=e=>{"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})};var s={};return(()=>{c.r(s),c.d(s,{plugin:()=>b});var e=c(305),t=c(650),n=c.n(t),r=c(545);const a=e=>e<1e11?1e3*e:e;var o=c(388),l=c(644);function i(e,t,n){return t in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e}function p(e){for(var t=1;t<arguments.length;t++){var n=null!=arguments[t]?arguments[t]:{},r=Object.keys(n);"function"==typeof Object.getOwnPropertySymbols&&(r=r.concat(Object.getOwnPropertySymbols(n).filter((function(e){return Object.getOwnPropertyDescriptor(n,e).enumerable})))),r.forEach((function(t){i(e,t,n[t])}))}return e}function m(e,t){return t=null!=t?t:{},Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(t)):function(e,t){var n=Object.keys(e);if(Object.getOwnPropertySymbols){var r=Object.getOwnPropertySymbols(e);n.push.apply(n,r)}return n}(Object(t)).forEach((function(n){Object.defineProperty(e,n,Object.getOwnPropertyDescriptor(t,n))})),e}const u={month:0,year:0,monthName:"",tempMonth:0,tempYear:0,tempMonthName:"",yearChoices:[],open:!1,loading:!0},d=["Janvier","Février","Mars","Avril","Mai","Juin","Juillet","Août","Septembre","Octobre","Novembre","Décembre"],y=e=>({invisable:l.css`
          display: none;
        `,tableCell:l.css`
        `,styledTable:l.css`
          //border-collapse: collapse;
          margin: 25px 0;
          //font-size: 0.9em;
          //font-family: sans-serif;
          min-width: 300px;
          box-shadow: 0 0 20px rgba(0, 0, 0, 0.15);
          text-align: center;
          width: 100%;

          td {
            padding: 5px 5px;
          }
        ;

          td.selected {
            background-color: ${e.colors.primary.main};
            color: ${e.colors.text.maxContrast}
          }
        ;

          td:not(.selected):hover {
            background-color: ${e.colors.secondary.main};
            color: ${e.colors.text.maxContrast};
          }
        ;
        `}),f=(e,t)=>{const n=new Date(t,e-1,1,0,0),o=new Date(n),l=new Date(o.setMonth(o.getMonth()+1));!function(e,t){let n={from:a(e),to:"now"};null==t||isNaN(t)||(n.to=a(t)),r.locationService.partial(n,!0)}(n.getTime(),l.getTime()-1)};function h(e,t){let n,a;switch(t.type){case"initialize":const o=t.options,l=(0,r.getTemplateSrv)().replace("$monthPicker");if(/^\d\d\d\d\-\d\d$/.test(l)){const e=l.split("-");n=parseInt(e[1],10),a=parseInt(e[0],10)}else{const e=new Date;n=e.getMonth()+1,a=e.getFullYear()}const c=[];for(let e=a-o.nbYearsBefore;e<a+o.nbYearsAfter;e++)c.push({label:e.toString(),value:e});return f(n,a),m(p({},e),{month:n,year:a,monthName:d[n-1],loading:!1,yearChoices:c});case"increment":return 12===e.month?(n=1,a=e.year+1):(n=e.month+1,a=e.year),f(n,a),m(p({},e),{month:n,year:a,monthName:d[n-1]});case"decrement":return 1===e.month?(n=12,a=e.year-1):(n=e.month-1,a=e.year),f(n,a),m(p({},e),{month:n,year:a,monthName:d[n-1]});case"selectMonth":return m(p({},e),{tempMonth:t.payload+1,tempMonthName:d[t.payload]});case"selectYear":return m(p({},e),{tempYear:t.payload});case"open":return m(p({},e),{tempMonth:e.month,tempYear:e.year,tempMonthName:e.monthName,open:!0});case"cancel":return m(p({},e),{open:!1});case"validate":return f(e.tempMonth,e.tempYear),m(p({},e),{month:e.tempMonth,year:e.tempYear,monthName:e.tempMonthName,open:!1});default:return p({},e)}}const b=new e.PanelPlugin((({options:e,data:r,width:a,height:c,replaceVariables:s})=>{const[i,p]=(0,t.useReducer)(h,u),m=(0,o.useStyles2)(y);return(0,t.useEffect)((()=>{p({type:"initialize",options:e})}),[e]),n().createElement("div",null,n().createElement("div",{style:{display:"flex",justifyContent:"center",verticalAlign:"center"}},n().createElement(o.Button,{variant:"secondary",onClick:()=>p({type:"decrement"})},"<"),n().createElement(o.Button,{variant:"secondary",onClick:()=>p({type:"open"}),fullWidth:!0},i.monthName," ",i.year),n().createElement(o.Button,{variant:"secondary",onClick:()=>p({type:"increment"})},">")),n().createElement(o.Modal,{title:e.modalTitle,isOpen:i.open,onDismiss:()=>p({type:"cancel"})},n().createElement("div",null,n().createElement(o.Select,{options:i.yearChoices,value:i.tempYear,onChange:e=>p({type:"selectYear",payload:Number(e.value)}),showAllSelectedWhenOpen:!0}),n().createElement("table",{className:(0,l.cx)(m.styledTable)},function(){let e=[];for(let t=0;t<4;t++){let r=[];for(let e=0;e<3;e++){const a=d[3*t+e];r.push(n().createElement("td",{onClick:()=>p({type:"selectMonth",payload:3*t+e}),className:`${(0,l.cx)(m.tableCell)} ${i.tempMonthName===a?"selected":""}`,key:3*t+e},a))}e.push(n().createElement("tr",null,r))}return e}()),n().createElement(o.HorizontalGroup,{justify:"flex-end"},n().createElement(o.Button,{variant:"primary",onClick:()=>p({type:"validate"})},"Valider"),n().createElement(o.Button,{variant:"secondary",onClick:()=>p({type:"cancel"})},"Annuler")))))})).setPanelOptions((e=>e.addTextInput({path:"modalTitle",name:"Titre fenêtre modale",defaultValue:"Sélection du mois et de l'année"}).addNumberInput({path:"nbYearsBefore",name:"Nb. années précédentes",defaultValue:5}).addNumberInput({path:"nbYearsAfter",name:"Nb. années suivantes",defaultValue:5})))})(),s})()));
//# sourceMappingURL=module.js.map